const { Router } = require('express');
const router = Router();

const {
    login,
    getroles,
    getUserById,
    createUser,
    getcategories,
    getproducts,
    insertcart,
    cartproducts,
    updateproduct
} = require('../controllers/index.controller');

router.get('/', (req, res) => {
    res.sendFile(__dirname + '/view/index.html');
});
router.get('/login', (req, res) => {
    res.sendFile(__dirname + '/view/login.html');
});
router.post('/login', login);
router.get('/roles', getroles);
router.post('/users', createUser);
router.get('/categories', getcategories);
router.get('/users/:id', getUserById);
router.get('/products', getproducts);
router.post('carts', insertcart);
router.post('/users/:productid', cartproducts)
router.put('/users/:productid', updateproduct);

module.exports = router;