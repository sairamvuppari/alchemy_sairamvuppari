const { Pool } = require('pg');
const bcrypt = require("bcryptjs")

const pool = new Pool({
    user: "postgres",
    password: "cyient#3",
    host: "localhost",
    port: 5432,
    database: "shopping_cart",
    dialect: 'postgres'
});

var currenttime = Date.now();

// user inputs in login Form using bcrypt algorithm encrypted the password.
const login = async(req, res) => {
    try {
        let username = req.body.username;
        let password = req.body.password;
        const saltRounds = 10;
        bcrypt.genSalt(saltRounds, function(err, salt) {
            if (err) {
                throw err
            } else {
                bcrypt.hash(password, salt, function(err, hash) {
                    if (err) {
                        throw err
                    } else {
                        console.log("encrypted", hash)
                        res.send(`Username: ${username} Password: ${[hash]}`);
                        const id = pool.query('SELECT roleid FROM users WHERE name=$1', [username]);
                        authorizeuser(id);
                    }
                })
            }
        })
    } catch (error) {
        error.message;
    }
}

//autorize user for particular Screns he is authorized
const authorizeuser = async(req, res) => {
    const id = parseInt(req.params.id);
    const result = await pool.query('SELECT role_name FROM roles WHERE roleid=$1', [id]);
    if (result == 'Merchant') {
        res.sendFile(__dirname + '/view/merchantscreen.html');
    } else {
        res.sendFile(__dirname + '/view/userscreen.html');
    }
}

const getroles = async(req, res) => {
    try {
        const response = await pool.query('SELECT roleid,roles_name FROM roles ORDER BY roleid ASC');
        res.json(response.rows);
        console.log(response);
    } catch (error) {
        error.message;
    }
}

//user registration
const createUser = async(req, res) => {
    try {
        const { name, email, phone, password, roleid } = req.body;
        const response = await pool.query('INSERT INTO users (name, email, phone,password,roleid,timestamp) VALUES ($1, $2,$3,$4,$5,$6)', [name, email, phone, password, roleid, currenttime]);
        res.json({
            message: 'User Added successfully',
            body: {
                user: { name, email }
            }
        })
    } catch (error) {
        error.message;
    }
};

const getUserById = async(req, res) => {
    try {
        const id = parseInt(req.params.id);
        const response = await pool.query('SELECT * FROM users WHERE userid = $1', [id]);
        res.json(response.rows);
    } catch (error) {
        error.message;
    }
};
//To get all categories available
const getcategories = async(req, res) => {
    try {
        const response = await pool.query('SELECT categoryid,category_name FROM categories ORDER BY categoryid ASC');
        res.json(response.rows);
    } catch (error) {
        error.message;
    }
}

//To get products available
const getproducts = async(req, res) => {
    try {
        const response = await pool.query('SELECT a.productid,a.product_name FROM products a, categories b where a.categoryid = b.categoryid');
        res.json(response.rows);
    } catch (error) {
        error.message;
    }
}

const insertcart = async(req, res) => {
    try {
        const { totalquantity, netAmount, userId } = req.body;
        const response = await pool.query('INSERT INTO carts (totalquantity,netAmount,userId,timestamp) VALUES ($1, $2,$3,$4)', [totalquantity, netAmount, userId, currenttime]);
        res.json({
            message: 'Added To cart successfully',
            body: {
                carts: { totalquantity, netAmount }
            }
        })
    } catch (error) {
        error.message;
    }
}

const cartproducts = async(req, res) => {
    const { totalquantity, netAmount, userId } = req.body;
    const response = await pool.query('SELECT count(productid) FROM products');
    var count = res.json(response.rows);
    try {
        const response1 = await pool.query('INSERT INTO carts (cartid,productid,totalquantity,netAmount,timestamp) VALUES ($1, $2,$3,$4,$5)', [cartid, productid, totalquantity, netAmount, currenttime]);
        res.json({
            message: 'Added To Final cart successfully',
            body: {
                cartproducts: { cartid, productid, totalquantity, netAmount }
            }
        })
    } catch (err) {
        console.log("Selected item is out of stock", err);
    }
}

//TO check all the products and update the stock products
const updateproduct = async(req, res) => {
    try {
        const { product_name, product_quantity } = req.body;

        const response = await pool.query('UPDATE products SET product_name = $1, product_quantity = $2 ', [
            product_name,
            product_quantity
        ]);
        res.json(`Product ${product_name} Updated Successfully`);
    } catch (error) {
        error.message;
    }
};

module.exports = {
    login,
    getroles,
    authorizeuser,
    getUserById,
    createUser,
    getcategories,
    getproducts,
    insertcart,
    cartproducts,
    updateproduct
};