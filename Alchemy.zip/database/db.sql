CREATE TABLE roles (
        roleid serial primary key,
        roles_name varchar,
        inserted_date timestamp
    );
    INSERT INTO roles (roles_name,inserted_date)
VALUES ('User',now()),('Merchant',now());
CREATE TABLE users (
        userid serial primary key,
        name varchar,
        email varchar,
        phone integer,
        password varchar,
        roleid integer,
        inserted_date timestamp
    );
    INSERT INTO users (name,email,phone,password,roleid,inserted_date)
    values('sairam','sairamvuppari@gmail.com','91827','sairam','1',now())
    ('alchemy','alchemytech@gmail,com','12398','2',now());
    CREATE TABLE categories (
        categoryid serial primary key,
        name varchar,
        inserted_date timestamp
    );
    CREATE TABLE products (
        productid serial primary key,
        name varchar,
        price varchar,
        product_quantity varchar,
        categoryid integer,
        inserted_date timestamp
    );
    CREATE TABLE carts (
        cartid serial primary key,
        totalquantity integer,
        netamount varchar,
        userId integer,
        inserted_date timestamp
    );
    CREATE TABLE cartproducts (
        cartproductsid serial primary key,
        cartid integer,
        productid integer,
        quantity varchar,
        netamount varchar,
        inserted_date timestamp
    );